import java.util.UUID;
public class Transaction {
    private final UUID uuid = UUID.randomUUID();
    private User receiver;
    private User sender;
    private String typeOfPayment;
    private double amountOfPayment;


    Transaction(User sender, User receiver, String typeOfPayment, double amountOfPayment) {
        this.receiver = receiver;
        this.sender = sender;
        this.amountOfPayment = amountOfPayment;
        this.typeOfPayment = typeOfPayment;
        sender.outgoing_payment(receiver, -amountOfPayment);
        receiver.incoming_payment(sender, amountOfPayment);
    }

    Transaction(UUID uuid, User sender, User receiver, String typeOfPayment, double amountOfPayment) {
        this.receiver = receiver;
        this.sender = sender;
        this.amountOfPayment = amountOfPayment;
        this.typeOfPayment = typeOfPayment;
        sender.outgoing_payment(receiver, -amountOfPayment);
        receiver.incoming_payment(sender, amountOfPayment);
    }

    public UUID getUuid() {return uuid;}

    @Override
    public String toString(){
        return "Transaction {" +
                "uuid=" + uuid +
                ", sender=" + sender.getUserName() +
                ", receiver=" + receiver.getUserName() +
                ", Amount=" + amountOfPayment +
                ", Type=" + typeOfPayment +
                '}';
    }
}