import java.util.UUID;

public class TransactionsService {
    private UsersList usersList = new UsersArrayList();
    void addUser(String name, double balance){
        User newUser = new User(name, balance);
        usersList.addUser(newUser);
    }
    double getUserBalance(int userId) throws UserNotFoundException{  //в месте вызова проверять на null
        double user_balance;
        try {
            user_balance = usersList.getUserById(userId).getBalance();
            return user_balance;
        } catch(UserNotFoundException Excp) {
//            System.out.println(Excp.getMessage() + "; " + "User ID: " + Excp.getIndx());
            throw new UserNotFoundException("Error: User not found", userId);
        }
    }
    
    void makeTransaction(int senderId, int receiverId, double payment_amount) throws UserNotFoundException{
            int userId = senderId;
        try {
            User sender = usersList.getUserById(senderId);
            userId = receiverId;
            User receiver = usersList.getUserById(receiverId);
            UUID uuid = UUID.randomUUID();
            Transaction SenderTransaction = new Transaction(uuid, sender, receiver, "OUTCOME", payment_amount);
            Transaction ReceiverTransaction = new Transaction(uuid, sender, receiver, "INCOME", payment_amount);
            sender.addTransaction(SenderTransaction);
            receiver.addTransaction(ReceiverTransaction);
        } catch(UserNotFoundException Excp) {
//            System.out.println(Excp.getMessage() + "; " + "User ID: " + Excp.getIndx());
            throw new UserNotFoundException("Error: User not found", userId);
        }

    }
    Transaction[] getUserTransactions(int userId) throws UserNotFoundException{
        try {
            User user = usersList.getUserById(userId);
            return user.getTransactionsArr();
    //        return usersList.getUserById(userId).getTransactionsArr();
        } catch(UserNotFoundException Excp) {
//            System.out.println(Excp.getMessage() + "; " + "User ID: " + Excp.getIndx());
            throw new UserNotFoundException("Error: User not found", userId);
        }
    }

    void removeTransaction(int userId, UUID uuid) throws UserNotFoundException{
        try {
            User user = usersList.getUserById(userId);
            user.removeTransaction(uuid);
        } catch(UserNotFoundException Excp) {
//            System.out.println(Excp.getMessage() + "; " + "User ID: " + Excp.getIndx());
            throw new UserNotFoundException("Error: User not found", userId);
        }
    }

    Transaction[] checkTransactions(){
        TransactionsList unpairedTrans = new TransactionsLinkedList();
        UUID curentUuid;
        for (int i = 0; i < usersList.getUsersQnty(); i++) {
            int transArrLen = usersList.getUserByIndx(i).getTransactionsArr().length;
            Transaction[] transactions = new Transaction[transArrLen];
            
        }
        
        

        return unpairedTrans.toArray();
    }
}


//    Добавить пользователя
//    Получить баланс пользователя.
//    Выполнить транзакцию перевода (указаны идентификаторы пользователей и сумма перевода).
//          В этом случае создаются две транзакции типа ДЕБЕТ/КРЕДИТ и добавляются к получателю и отправителю.
//          Идентификаторы обеих транзакций должны быть одинаковыми;
//    Получить переводы определенного пользователя (возвращается МАССИВ переводов). 
//    Удалить транзакцию по ID для определенного пользователя
//          (указываются ID транзакции и ID пользователя);
//    Проверка транзакций (возвращает МАССИВ непарных транзакций).