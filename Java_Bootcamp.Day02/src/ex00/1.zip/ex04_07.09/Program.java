public class Program {
    public static void main(String[] args) {
        User Receiver1 = new User("Bill", 500);
        User Sender1 = new User("Dim", 1000);
        User Usr3 = new User("Ira", 1500);
        
//        System.out.println(Receiver1.getUserId() + " " +Receiver1.getUserName() + " " + Receiver1.getBalance());
//        System.out.println(Sender1.getUserId() + " " + Sender1.getUserName() + " " + Sender1.getBalance());
        System.out.println(Receiver1);
        System.out.println(Sender1);
        System.out.println(Usr3);
        UsersArrayList usrLst = new UsersArrayList();
        usrLst.addUser(Sender1);
        usrLst.addUser(Receiver1);
        usrLst.addUser(Usr3);

        System.out.println("We have " + usrLst.getUsersQnty() + " users");

        Transaction tr1 = new Transaction(Sender1, Usr3, "INCOME", 120);
        Sender1.addTransaction(tr1);
        Transaction tr2 = new Transaction(Sender1, Receiver1, "INCOME", 95);
        Sender1.addTransaction(tr2);
        Receiver1.addTransaction(tr2);

        Transaction[] trArr1 = Sender1.getTransactionsArr();
        for(Transaction transaction : trArr1) {
            System.out.println(transaction.toString());
        }

        System.out.println(Receiver1);
        System.out.println(Sender1);
        System.out.println(Usr3);
    }
}